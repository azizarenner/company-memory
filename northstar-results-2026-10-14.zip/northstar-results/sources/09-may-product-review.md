# Product review: setup guidance
Date: 2026-05-04
Document status: review and proposal; not an approved release commitment

Product reviewed the April 20 support observations alongside the April 24 pilot review and the May 1 onboarding decision.

Cedar's connector-selection question suggests that clearer connector guidance could help some customers. Vale's approval question concerns the customer's internal coordination and might not be resolved by interface changes alone. Finch's unaided setup is a reminder that the selected examples do not show that every customer needs guided onboarding.

We propose a connector-selection checklist for future consideration. No delivery date, implementation approval or expected conversion improvement is established by this review. Assisted onboarding is the approved operating approach for enterprise trials; the proposed checklist is a separate potential product improvement.
