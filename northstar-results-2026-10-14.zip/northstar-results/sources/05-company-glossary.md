# Northstar vocabulary
Date: 2026-05-02
Document status: maintained company reference

Northstar is a fictional service that helps customer teams configure a shared workspace and connect a sample data source during a trial.

A workspace is the customer's shared Northstar environment. Setup means creating a workspace and connecting a sample data source. Assisted onboarding means a Customer Success specialist guides the customer through setup; it does not mean that the specialist can bypass customer approval or collect credentials.

Account segment is the enterprise or smaller-customer label recorded in the account register. This glossary does not define how that label is assigned or an employee-count threshold. If the label is absent, Sales Operations is the contact for resolving the record.

A setup blocker is a problem that prevents completion of setup. A setup question is a request for guidance that does not necessarily prevent setup. These terms must not be treated as interchangeable in reporting.

Trial activation means a workspace has connected a sample data source. It does not establish a purchase, paid conversion or completion of the full evaluation.
