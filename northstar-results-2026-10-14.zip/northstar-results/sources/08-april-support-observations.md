# Trial setup observations
Date: 2026-04-20
Document status: observation log; not a representative customer survey

Support recorded three illustrative cases from the trial pilot:
- Cedar: account register label enterprise. Its administrator could not determine which sample-data connector to select and requested a guided setup session.
- Finch: account register label smaller-customer. The customer connected a sample data source without contacting Support.
- Vale: account register label enterprise. The administrator asked which colleague should approve a sample-data connection; setup was paused while the customer resolved this internally.

These cases contain no employee counts, conversion outcomes, measured setup times or comparison with an assisted-onboarding group. They were selected to illustrate different setup experiences, not to estimate how often problems occur. This log does not establish whether the April 24 review used these particular cases.
