# Trial reporting definitions
Date: 2026-05-05
Document status: maintained reporting reference

Activation rate for a named trial cohort is the number of workspaces in that cohort that connected a sample data source divided by the number of trial workspaces in that same cohort. Every report must state the cohort dates and observation cutoff. A missing connection observation must not automatically be recorded as a confirmed setup blocker.

There are no cohort counts or activation-rate values in this reference. The April 20 illustrative cases cannot establish the company's activation rate. Activation is not paid conversion. No supplied document reports a causal effect of assisted onboarding on activation or conversion.
