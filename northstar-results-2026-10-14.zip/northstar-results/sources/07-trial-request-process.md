# Preparing a trial setup request
Date: 2026-05-03
Document status: approved process; effective May 3, 2026

For a new trial request:
1. Record the account name, the account register's segment label if present, the customer's setup goal and any reported blocker.
2. If the segment label is missing, request clarification from Sales Operations. Do not infer the label from employee count. Prepare an incomplete draft while waiting; do not select an onboarding route yet.
3. For an enterprise label, prepare an assisted-onboarding request for the Customer Success trial setup queue. For a smaller-customer label, the self-service option remains available under the May 1 decision; Support handles reported setup questions.
4. Include source references and unresolved questions in the handoff. Do not promise a trial duration unless a current approval establishing that duration is available.

The request template has six fields: account; recorded segment; setup goal; reported blocker; proposed route; unresolved questions.

This document defines preparation and routing. It does not authorize an agent to send a message, create an account, change settings or act on the customer's behalf. Actions require separate authorization from the person operating the agent.
