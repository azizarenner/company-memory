# Who handles trial work
Date: 2026-05-02
Document status: approved operating responsibilities; effective May 2, 2026

Sales Operations maintains account segment labels and resolves missing labels. This document does not give other teams a rule for deriving a segment from employee count.

Customer Success coordinates assisted onboarding and owns the trial setup request queue. Support records setup questions and blockers and links those observations to the relevant request. Product reviews recurring setup problems and decides whether to propose product changes.

These routing responsibilities do not grant any team authority to waive the May onboarding decision. No exception approver is named here. Escalating a question to the responsible queue is not approval to change policy.
