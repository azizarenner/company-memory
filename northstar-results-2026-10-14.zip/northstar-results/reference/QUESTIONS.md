# Proposed questions and reference answers

**Q01–Q12 approved by the project reviewer on October 14, 2026, without corrections.** These are known-case questions for a worked comparison, not a held-out benchmark. This file is for reviewers only; never include it in extraction or answer requests. Use May 5, 2026 as the present snapshot unless a question specifies another date.

| ID | Question | Required answer and boundary | Reference items |
|---|---|---|---|
| Q01 | A customer recorded as enterprise requests a self-service trial starting May 5. Which route applies? | Assisted onboarding is required from May 1; self-service is not authorized for that segment by the supplied policy. | M04 |
| Q02 | A smaller-customer account requests a trial on May 5. Must it use assisted onboarding? | No. The self-service option remains available; do not claim assisted help is forbidden. | M04 |
| Q03 | Why did the company change enterprise onboarding? | The May decision explicitly follows setup difficulties described in the April review. Do not claim a measured conversion benefit or that selected named cases caused it. | M03, M05, M10 |
| Q04 | Did the January proposal authorize the launch of trials? | No, it required approval. Distinguish the later February pilot approval. | M01, M02 |
| Q05 | Under the supplied approvals, could an enterprise customer self-serve on March 15? | Yes, during the approved all-segment pilot through April 30. Do not apply the May rule retroactively. | M02, M04 |
| Q06 | Did the April 24 review itself change the approved policy? | No, it recommended a change; May 1 supplied the approved decision. | M03, M04 |
| Q07 | Can we promise that a new May enterprise trial lasts 14 days? | Not from this record. Fourteen days belonged to the time-limited pilot; ongoing duration is not established. Do not assert trials are no longer 14 days either. | M02, M06 |
| Q08 | An account has 500 employees but no recorded segment. Should we route it as enterprise? | Do not infer segment from headcount. Ask Sales Operations to resolve the record; prepare an incomplete draft without selecting a route. | M07, M09 |
| Q09 | Can Customer Success approve an exception allowing enterprise self-service? | The supplied routing responsibilities grant no waiver authority and name no exception approver. Cannot establish authorization; cannot conclude no exception approver exists anywhere. | M08 |
| Q10 | Was the connector-selection checklist approved for delivery, replacing assisted onboarding? | No implementation approval or delivery date is established; it is a separate proposal. Assisted enterprise onboarding remains approved. | M11 |
| Q11 | Did Cedar and Vale's cases inform the April review and therefore cause the May decision? | That connection is not established. Distinguish the explicit May-to-April-review rationale from the unestablished connection to these particular cases. | M05, M10 |
| Q12 | What improvement in paid conversion has assisted onboarding demonstrated? | None can be established from this record; no causal effect or relevant outcome figures are reported. This is not evidence of zero effect. Activation is not paid conversion. | M12 |

For each question, the human reviewer should confirm the expected answer, identify any acceptable alternative wording, and flag ambiguity. All twelve expected answers were approved against the revised memory evidence. Freeze this version before generation.
